# deepfakedetection
deepfake image detection
This notebook uses CNN algorithm(MesoNet) to predict if the given input image of is deepfake or not deepfake.
